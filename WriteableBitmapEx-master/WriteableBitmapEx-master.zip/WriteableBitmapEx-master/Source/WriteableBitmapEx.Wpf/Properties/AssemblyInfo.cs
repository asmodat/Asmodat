﻿#region Header
//
//   Project:           WriteableBitmapEx - WriteableBitmap extensions
//   Description:       Assembly Infos.
//
//   Changed by:        $Author: unknown $
//   Changed on:        $Date: 2015-02-24 20:36:41 +0100 (Di, 24 Feb 2015) $
//   Changed in:        $Revision: 112951 $
//   Project:           $URL: https://writeablebitmapex.svn.codeplex.com/svn/trunk/Source/WriteableBitmapEx.Wpf/Properties/AssemblyInfo.cs $
//   Id:                $Id: AssemblyInfo.cs 112951 2015-02-24 19:36:41Z unknown $
//
//
//   Copyright © 2009-2015 Rene Schulte and WriteableBitmapEx Contributors
//
//   This code is open source. Please read the License.txt for details. No worries, we won't sue you! ;)
//
#endregion

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("WriteableBitmapEx.Wpf")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("The WriteableBitmapEx library is a collection of extension methods for the WriteableBitmap. The extension methods are easy to use like built-in methods and offer GDI+ like functionality for Silverlight web, Windows Phone, WPF and WinRT.")]

[assembly: Guid("2f062d6e-c93d-4300-b408-2d612aa9b885")]
